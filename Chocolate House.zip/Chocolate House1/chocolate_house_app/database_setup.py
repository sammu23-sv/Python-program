import sqlite3

def initialize_database():
    connection = sqlite3.connect('chocolate_house.db')
    cursor = connection.cursor()

    # Create tables for flavors, ingredients, and feedback
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS SeasonalFlavors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flavor_name TEXT NOT NULL,
            season TEXT NOT NULL,
            details TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Ingredients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ingredient_name TEXT NOT NULL,
            stock INTEGER NOT NULL
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS CustomerFeedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flavor_name TEXT NOT NULL,
            allergy_info TEXT,
            feedback TEXT
        )
    ''')

    connection.commit()
    connection.close()

if __name__ == "__main__":
    initialize_database()