from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

# Database connection function
def get_db_connection():
    conn = sqlite3.connect('chocolate_house.db')
    conn.row_factory = sqlite3.Row  # This allows us to access columns by name
    return conn

# Route to display all flavors and ingredients
@app.route('/')
def index():
    conn = get_db_connection()
    flavors = conn.execute('SELECT * FROM SeasonalFlavors').fetchall()
    ingredients = conn.execute('SELECT * FROM Ingredients').fetchall()
    conn.close()
    return render_template('index.html', flavors=flavors, ingredients=ingredients)

# Route to add a new flavor
@app.route('/add_flavor', methods=['GET', 'POST'])
def add_flavor():
    if request.method == 'POST':
        name = request.form['name']
        season = request.form['season']
        details = request.form['details']
        
        conn = get_db_connection()
        conn.execute('INSERT INTO SeasonalFlavors (flavor_name, season, details) VALUES (?, ?, ?)', (name, season, details))
        conn.commit()
        conn.close()
        
        return redirect(url_for('index'))
    
    return render_template('add_flavor.html')

# Route to add a new ingredient
@app.route('/add_ingredient', methods=['GET', 'POST'])
def add_ingredient():
    if request.method == 'POST':
        ingredient_name = request.form['ingredient_name']
        stock = request.form['stock']
        
        conn = get_db_connection()
        conn.execute('INSERT INTO Ingredients (ingredient_name, stock) VALUES (?, ?)', (ingredient_name, stock))
        conn.commit()
        conn.close()
        
        return redirect(url_for('index'))
    
    return render_template('add_ingredient.html')

# Route to submit customer feedback
@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        flavor_name = request.form['flavor_name']
        allergy_info = request.form['allergy_info']
        feedback_text = request.form['feedback']
        
        conn = get_db_connection()
        conn.execute('INSERT INTO CustomerFeedback (flavor_name, allergy_info, feedback) VALUES (?, ?, ?)', (flavor_name, allergy_info, feedback_text))
        conn.commit()
        conn.close()
        
        return redirect(url_for('index'))
    
    return render_template('feedback.html')

# Route to delete a flavor or ingredient by ID (optional)
@app.route('/delete/<table>/<int:id>')
def delete_item(table, id):
    conn = get_db_connection()
    
    if table == 'flavor':
        conn.execute('DELETE FROM SeasonalFlavors WHERE id = ?', (id,))
    elif table == 'ingredient':
        conn.execute('DELETE FROM Ingredients WHERE id = ?', (id,))
    
    conn.commit()
    conn.close()
    
    return redirect(url_for('index'))

if __name__ == "__main__":
   app.run(debug=True)